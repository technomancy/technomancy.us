require 'rubygems'
require 'erb'
require 'yaml'
require 'redcloth'

class Presentation
  def initialize(dir)
    @dir = dir + '/'
    @title = File.read(dir + '/title').chomp
  end

  def render # source files must start with a word character
    @files = (Dir.entries(@dir + '/src')).select{ |f| f.match(/^\w/) }.sort
    @files.each_with_index { |f, i| render_file(f, i) }
  end

  def render_file(file, count)
    @content = File.read(@dir + '/src/' + file)
    html = ERB.new(TEMPLATE).result( binding )
    File.open(@dir + file + '.html', 'w') { |f| f.puts html }
  end
end

TEMPLATE = File.read(File.dirname(__FILE__) + '/present.erb')

Presentation.new(ARGV.first).render
