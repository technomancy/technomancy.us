cd ~/documents/presentations/
ruby present.rb trac