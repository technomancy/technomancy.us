cd ~/documents/presentations/
ruby present.rb hello_rails