require "#{File.dirname(__FILE__)}/../test_helper"

class StoriesTest < ActionController::IntegrationTest
  fixtures :users, :meetings, :attendances

  def test_signup
    get "/"
    assert_response :redirect

    get "/signup"
    assert_response :success
    assert_template "account/signup"

    post "/signup", { :user => { :email => "why@whytheluckystiff.net",
        :password => "chunky bacon", :password_confirmation => "chunky bacon" } }

    assert_equal nil, flash[:error]
    assert_equal "Thanks for signing up! You're all logged in now.", flash[:notice]
    assert_response :redirect

    follow_redirect!

    assert_response :success
    assert_template "meeting/index"
  end

  def test_login
     do_login

    follow_redirect!
    assert_response :success
    assert_template "meeting/index"
  end

  def test_forgot_password
    get "/forgot_password"
    assert_response :success

    post "/forgot_password", :email => 'quentin@example.com'
    assert_response :redirect

    follow_redirect!
    assert_response :success
    assert_template "account/enter_password_token"

    post "/enter_password_token", { :token => users(:quentin).password_reset_token, :email => "quentin@example.com",
      :user => { :password => 'test2', :password_confirmation => 'test2'} }
    assert_equal nil, flash[:error]
    assert_response :redirect

    follow_redirect!
    assert_response :success
    assert_template 'account/login'
  end
  
  def test_create_meeting
    do_login
    
    get '/meeting/new'
    assert_response :success
    
    post '/meeting/create', :meeting => { :name => 'Blah', :description => 'blah blah blah',
      :earliest => '2006-07-02', :latest => '2006-08-02', :length => 2,
      :time_begin => 10, :time_end => 13, :decide_by => '2006-07-01',
      :attendees => 'justin@example.com, bob@example.com'
    }

    assert_equal nil, flash[:error]
    assert_response :redirect
    follow_redirect!
    assert_response :success
    assert_template 'attendance/show'
  end

   def test_edit_meeting
     do_login
    
     get '/meeting/edit/1'
     assert_response :success
    
     post '/meeting/update/1', :meeting => { :name => 'Blagh', :description => 'blah BLAH', :decide_by => '2006-02-02' }

     assert_equal nil, flash[:error]
     assert_response :redirect
     follow_redirect!
     assert_response :success
     assert_template 'meeting/index'
   end

  def test_set_times
    do_login

    get 'attendance/show/1'
    assert_response :success

    post 'attendance/update/1', :times => { '2006-06-19' => { 18 => '1', 19 => '1', 20 => '1' } }
    assert_equal nil, flash[:error]
    assert_response :redirect
    follow_redirect!
    assert_response :success
    assert_template 'meeting/index'
  end

  def test_decide_time
    do_login

    post '/meeting/decide/1', :chosen_time => "2006-06-17 20:00:00"
    assert_response :redirect
    assert_equal nil, flash[:error]
    follow_redirect!
    assert_template "meeting/index"
  end

  private

  def do_login
    post "/login", :email => "quentin@example.com", :password => "test"
    assert_response :redirect
  end
end
