require File.dirname(__FILE__) + '/../test_helper'
require 'meeting_controller'

# Re-raise errors caught by the controller.
class MeetingController; def rescue_action(e) raise e end; end

class MeetingControllerTest < Test::Unit::TestCase
  include AuthenticatedTestHelper
  fixtures :users, :meetings, :attendances
  
  def setup
    @controller = MeetingController.new
    @request    = ActionController::TestRequest.new
    @response   = ActionController::TestResponse.new
    login_as :quentin
  end

  def test_new_form
    get :new
    assert_response :success
  end

  def test_create
    c = Meeting.count
    post :create, :meeting =>
      { :name => "Quentin's Party II - Quentin's party strikes back!",
      :description => "This time, there will be no survivors...",
      :length => 2,
      :earliest => Date.today + 2.days,
      :latest => Date.today + 1.weeks,
      :time_begin => 9, :time_end => 17,
      :decide_by => Date.today + 1.days }

    assert_response :redirect
    assert assigns(:meeting)
    assert !assigns(:meeting).new_record?
  end

  def test_edit_form
    get :edit, { :id => 1 }
    assert_response :success
  end

  def test_edit_save
    assert_no_difference Attendance, :count do 
      post :update, { :id => 1, "meeting"=>{"name"=>"aoeuoooo", "attendees"=>"", "time_begin"=>"15", "length"=>"1", "description"=>"aoeu", "latest"=>"2006-11-28", "decide_by"=>"2006-11-20", "earliest"=>"2006-11-25", "length" => 9}}
    end
    assert_equal 15, assigns(:meeting).time_begin
    assert_equal 9, assigns(:meeting).length
  end

  def test_invalid_edit
    post :update, :id => 1, :meeting => { :time_begin => 15, :time_end => 10 }

    assert_response :success
    assert assigns(:meeting).errors.on(:time_begin)
  end

  def test_unauthorized_edit
    get :edit, :id => 2
    assert_response :redirect
    assert flash[:error]
    post :update, :id => 2
    assert_response :redirect
    assert flash[:error]
  end

  def test_decide_open_meeting
    post :decide, :id => 3, :chosen_time => "2005-05-05 10:10:10"
    assert_response :redirect
    assert flash[:error]
  end
  
  def test_decide
    post :decide, :id => 1, :chosen_time => "2006-06-17 20:00:00"
    assert_response :redirect
    assert_equal nil, flash[:error]
    assert_equal Time.parse("2006-06-17 20:00:00"), assigns(:meeting).chosen_time
  end

  def test_decide_not_ready
    login_as :arthur
    get :decide, { :id => 2 }
    assert_response :success
    assert_match /Not all the attendees have specified times yet./, @response.body
    
    post :decide, { :id => 2, :chosen_time => "2006-08-21 17:00:00" }
    assert_response :redirect
    assert_equal Time.parse("2006-08-21 17:00:00"), assigns(:meeting).chosen_time
  end
  
  def test_decide_bad_time
    @request.env["HTTP_REFERER"] = "http://concour.se"
    post :decide, :id => 1, :chosen_time => "2005-05-05 10:10:10"
    assert_response :success
    assert flash[:error]
  end

  def test_decide_sends_email
     post :decide, :id => 1, :chosen_time => "2006-06-17 20:00:00"
     assert_response :redirect, :action => 'index'
     
    assert_nil flash[:error]
    assert flash[:notice].include?("17 Jun 2006")
    assert flash[:notice].include?("8:00")
    
    delivery = ActionMailer::Base.deliveries.last
    assert delivery
    assert_equal "Meeting time for #{assigns(:meeting).name} has been decided.", delivery.subject, "Decision notification not sent."
   end

  def test_invite_self
    post :create, :meeting =>
      { :name => "Quentin's Party III - Picking up the pieces",
      :description => "The trilogy is complete",
      :length => 2,
      :earliest => Date.today + 2.days,
      :latest => Date.today + 1.weeks,
      :time_begin => 9, :time_end => 17,
      :decide_by => Date.today + 1.days,
      :attendees => "quentin@example.com, bob@example.com"
    }

    assert_response :redirect
    assert assigns(:meeting)
    assert !assigns(:meeting).new_record?

    assert_equal 2, assigns(:meeting).attendances.size
    assert assigns(:meeting).attendances.map{ |a| a.user.email }.include?('bob@example.com')
    assert assigns(:meeting).attendances.map{ |a| a.user.email }.include?('quentin@example.com')
  end
end
