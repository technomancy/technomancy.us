require File.dirname(__FILE__) + '/../test_helper'
require 'attendance_controller'

# Re-raise errors caught by the controller.
class AttendanceController; def rescue_action(e) raise e end; end

class AttendanceControllerTest < Test::Unit::TestCase
  include AuthenticatedTestHelper
  fixtures :users, :meetings, :attendances

  def setup
    @controller = AttendanceController.new
    @request    = ActionController::TestRequest.new
    @response   = ActionController::TestResponse.new
    login_as :quentin
  end

  def test_show
    get :show, { :id => 1 }
    assert_equal nil, flash[:error]
    assert_response :success
    assert assigns(:meeting)
  end

  def test_update
    post :update, :id => 1, :times => {'2006-06-27' => {12 => 1, 14 => 1, 17 => 1, 19 => 1},
      '2006-06-29' => {12 => 1, 15 => 1, 17 => 1, 20 => 1, 21 => 1, 23 => 1}}

    assert_equal [12, 14, 17, 19], assigns(:attendance).times[Date.parse("2006-06-27")].sort
  end
  
  def test_set_another_time
    @request.session[:user] = 3 # can't change this mid-action!
    post :update, :id => 4, :times => {'2006-06-16' => {12 => 1, 13 => 1}}
    assert_response :redirect
    assert_equal nil, flash[:error]
    assert flash[:notice]
  end

  def test_set_bad_times
    post :update, :id => 1, :times => {'2006-06-27' => {1 => 1, 4 => 1, 7 => 1, 9 => 1},
      '2006-06-29' => {12 => 1, 15 => 1, 17 => 1, 20 => 1, 21 => 1, 23 => 1}}
    assert flash[:error]
  end

  def test_unauthorized_show
    get :show, :id => 3
    assert_response :redirect
    assert flash[:error]
  end

  def test_notify_organizer
    meeting = Meeting.find(2)
    assert ! meeting.ready?
    
    post :update, :id => 8, :times => {'2006-08-20' => {17 => "1", 19 => "1"}}
    assert_response :redirect, :action => 'index'
    
    meeting.reload
    
    assert_equal nil, flash[:error]
    assert_equal "Your times have been saved.", flash[:notice]
    assert_equal [17, 19], assigns(:attendance).times[Date.parse("2006-08-20")]

    assert_equal 2, meeting.attendances.size
    meeting.attendances.each do |attend|
      assert attend.entered?, "Time for #{attend.to_s} not entered"
    end
    assert meeting.ready?

    delivery = ActionMailer::Base.deliveries.last
    assert delivery
    assert_equal "You can now decide on a time for #{meeting.name}.", delivery.subject, "Meeting ready notification not sent."
  end

  def test_post_no_times
    post :update, :id => 1
    assert_response :redirect
    assert_equal({}, attendances(:quentin_party).times)
#    assert attendances(:quentin_party).entered?
  end
end
