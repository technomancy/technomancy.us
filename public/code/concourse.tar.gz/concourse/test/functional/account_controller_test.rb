require File.dirname(__FILE__) + '/../test_helper'
require 'account_controller'

# Re-raise errors caught by the controller.
class AccountController; def rescue_action(e) raise e end; end

class AccountControllerTest < Test::Unit::TestCase
  # Be sure to include AuthenticatedTestHelper in test/test_helper.rb instead
  # Then, you can remove it from this and the units test.
  include AuthenticatedTestHelper

  fixtures :users

  def setup
    @controller = AccountController.new
    @request    = ActionController::TestRequest.new
    @response   = ActionController::TestResponse.new
  end

  def test_should_login_and_redirect
    post :login, :email => 'quentin@example.com', :password => 'test'
    assert session[:user]
    assert_response :redirect
  end

  def test_should_fail_login_and_not_redirect
    post :login, :email => 'quentin@example.com', :password => 'bad password'
    assert_nil session[:user]
    assert_response :success
  end

  def test_should_allow_signup
    assert_difference User, :count do
      create_user
      assert_response :redirect
    end
  end

  def test_should_require_login_on_signup
    assert_no_difference User, :count do
      create_user(:email => nil)
      assert assigns(:user).errors.on(:email)
      assert_response :success
    end
  end

  def test_should_require_password_on_signup
    assert_no_difference User, :count do
      create_user(:password => nil)
      assert assigns(:user).errors.on(:password)
      assert_response :success
    end
  end

  def test_should_require_password_confirmation_on_signup
    assert_no_difference User, :count do
      create_user(:password_confirmation => nil)
      assert assigns(:user).errors.on(:password_confirmation)
      assert_response :success
    end
  end

  def test_should_require_email_on_signup
    assert_no_difference User, :count do
      create_user(:email => nil)
      assert assigns(:user).errors.on(:email)
      assert_response :success
    end
  end

  def test_should_logout
    login_as :quentin
    get :logout
    assert_nil session[:user]
    assert_response :redirect
  end
  
  def test_password_reset_rejects_nonexisting_user
    post :forgot_password, :email => 'non_existant@gmail.com'
    assert flash[:error]['found']
  end

  def test_password_reset_accepts_existing_user
    post :forgot_password, :email => users(:technomancy).email

    assert flash.empty?
    assert_redirected_to :controller => 'account', :action => 'enter_password_token', :email => users(:technomancy).email
    assert delivery = ActionMailer::Base.deliveries.last
    assert_equal users(:technomancy).email, delivery.to.to_s
    assert delivery.body.include?(users(:technomancy).password_reset_token)
  end

  def test_token_entry_rejects_wrong_token
    karnickel = users(:technomancy)

    post :enter_password_token, :id => karnickel.id, :token => "__no_token__"
    assert flash[:error]['incorrect']
  end

  def test_token_entry_accepts_correct_and_saves_new_password
    karnickel = users(:technomancy)

    post :enter_password_token, :email => karnickel.email, :token => karnickel.password_reset_token, :user => {:password => "enigma", :password_confirmation => "enigma"}

    assert_equal nil, flash[:error]
    assert flash[:notice]['saved']
    
    karnickel.reload
    assert karnickel.authenticated?('enigma')
  end

  protected
    def create_user(options = {})
      post :signup, :user => { :email => 'quire@example.com', 
        :password => 'quire', :password_confirmation => 'quire' }.merge(options)
    end
end
