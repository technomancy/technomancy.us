require File.dirname(__FILE__) + '/../test_helper'

class AttendanceTest < Test::Unit::TestCase
  fixtures :attendances

  def test_entered
    assert attendances(:quentin_party).entered?
    assert attendances(:arthur_party).entered?
    assert !attendances(:tm_lunch).entered?
  end
  
  def test_good_time
    assert attendances(:quentin_party).good_time?(Time.parse("2006-06-17 23:00:00"))
    assert attendances(:quentin_party).good_time?(Time.parse("2006-06-17 19:00:00"))
    assert ! attendances(:quentin_party).good_time?(Time.parse("2006-06-17 01:00:00"))
    assert attendances(:quentin_party).good_time?(Time.parse("2006-06-18 16:00:00"))
    assert ! attendances(:quentin_party).good_time?(Time.parse("2006-06-18 01:00:00"))

    assert ! attendances(:arthur_party).good_time?(Time.parse("2006-06-17 01:00:00"))
    assert attendances(:arthur_party).good_time?(Time.parse("2006-06-17 20:00:00"))
  end
end
