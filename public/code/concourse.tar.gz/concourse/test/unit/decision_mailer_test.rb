require File.dirname(__FILE__) + '/../test_helper'
require 'decision_mailer'

class DecisionMailerTest < Test::Unit::TestCase
  FIXTURES_PATH = File.dirname(__FILE__) + '/../fixtures'
  CHARSET = "utf-8"

  fixtures :meetings, :users, :attendances
  
  include ActionMailer::Quoting

  def setup
    ActionMailer::Base.delivery_method = :test
    ActionMailer::Base.perform_deliveries = true
    ActionMailer::Base.deliveries = []

    @expected = TMail::Mail.new
    @expected.set_content_type "text", "plain", { "charset" => CHARSET }
  end

  def test_deliver_meeting_ready_notification
    meeting = meetings(:party_like_mad)

    DecisionMailer.deliver_meeting_ready_notification(meeting)

    delivery = ActionMailer::Base.deliveries.last

    assert delivery
    assert_equal meeting.organizer.email, delivery.to.to_s
  end

  def test_deliver_meeting_decided_notification
    meeting = meetings(:party_like_mad)

    DecisionMailer.deliver_meeting_decided_notification(meeting)

    delivery = ActionMailer::Base.deliveries.last

    assert delivery

    meeting.attendances.each do |attend|
      assert delivery.to.to_s.include?(attend.user.email), "Decision notification not sent to #{attend.user.email}."
    end
  end
  
  private
    def read_fixture(action)
      IO.readlines("#{FIXTURES_PATH}/decision_mailer/#{action}")
    end

    def encode(subject)
      quoted_printable(subject, CHARSET)
    end
end
