require File.dirname(__FILE__) + '/../test_helper'

class MeetingTest < Test::Unit::TestCase
  include AuthenticatedTestHelper
  fixtures :meetings, :users, :attendances

  # Replace this with your real tests.
  def test_valid_time
    assert ! meetings(:party_like_mad).valid_date?(Time.parse("2007-07-29 21:43:32.002686 -07:00"))
  end

  def test_overdue
    assert meetings(:old_meeting).overdue?
  end

  def test_status
    assert_equal :open, meetings(:arthurs).status
    assert_equal :ready, meetings(:party_like_mad).status
    assert_equal :decided, meetings(:old_meeting).status
  end

  def test_cant_decide_invalid_time
    assert_raise(RuntimeError) do
      meetings(:party_like_mad).decide(Time.parse("2005-05-05 10:10:10"))
    end
  end

  def test_good_for_everyone
    assert meetings(:party_like_mad).good_for_everyone(Time.parse("2006-06-17 15:00:00"))
    assert meetings(:party_like_mad).good_for_everyone(Time.parse("2006-06-18 15:00:00"))
    assert ! meetings(:party_like_mad).good_for_everyone(Time.parse("2006-06-17 01:00:00"))
    assert ! meetings(:party_like_mad).good_for_everyone(Time.parse("2006-06-18 10:00:00"))
  end

  def test_date_validations
    assert_no_difference Meeting, :count do
      m = create_meeting(:earliest => Time.now, :latest => Time.now - 1.day)
      assert m.errors.on(:earliest)

      m = create_meeting(:earliest => Time.now,
                         :latest => Time.now + 1.day,
                         :decide_by => Time.now + 1.day)
      assert m.errors.on(:decide_by)
    end
  end

  def test_time_validations
    assert_no_difference Meeting, :count do
      m = create_meeting(:time_begin => 10,
                         :time_end => 5)
      assert m.errors.on(:time_begin)
    end
  end
  
  def test_attendances_added
    m = create_meeting(:attendees => "bob@example.com, arthur@example.com", :user_id => 1)
    assert_equal 3, m.attendances.size
    assert_equal ["arthur@example.com", "bob@example.com", "quentin@example.com"],
      m.users.map(&:email).sort
  end

  def test_times_that_work
    t = meetings(:party_like_mad).times_that_work
    hash_one = { 14 => [2], 15 => [1, 2],
        16 => [1, 2],
        19 => [1],
        20 => [1, 2],
        21 => [1, 2],
        22 => [1, 2],
      23 => [1]}
    hash_two = { 9 => [2],
        10 => [2],
        11 => [2],
        12 => [2],
        13 => [2],
        14 => [2],
        15 => [1, 2],
        16 => [1],
        17 => [1],
        18 => [1],
        19 => [1],
        20 => [1]
      }
    assert_equal hash_one, t[Date.parse('2006-06-17')]
    assert_equal hash_two, t[Date.parse('2006-06-18')]
  end

  def test_times_that_work_for_all
    t = meetings(:party_like_mad).times_that_work_for_all

    assert_equal [15, 16, 20, 21, 22], t[Date.parse('2006-06-17')]
    assert_equal [15], t[Date.parse('2006-06-18')]
  end

  def test_times_that_work_and_fit
    assert_equal [(20 .. 22)], meetings(:party_like_mad).times_that_work_and_fit[Date.parse('2006-06-17')]
  end
  
  def test_hours_that_fit
    assert_equal [(20 .. 22)], meetings(:party_like_mad).hours_that_fit([15, 16, 20, 21, 22])
  end

  def test_who_at
    date = Date.parse '2006-06-17'
    assert_equal [users(:quentin), users(:arthur)], meetings(:party_like_mad).who_at(date, 20)
    assert_equal [users(:quentin), users(:arthur)], meetings(:party_like_mad).who_at(date, 15)
    assert_equal [users(:arthur)], meetings(:party_like_mad).who_at(date, 14)
  end
  
  def test_how_many_at_hour
    assert_equal 2, meetings(:party_like_mad).how_many_at(Date.parse('2006-06-17'), 20)
  end

  def test_who_at_for_length
    date = Date.parse '2006-06-17'
    assert_equal [users(:quentin), users(:arthur)], meetings(:party_like_mad).who_at_for_length(date, 20)
    assert_equal [users(:quentin)], meetings(:party_like_mad).who_at_for_length(date, 21)
  end
  
  protected
  def create_meeting(options = {})
    m = Meeting.create({ :name => 'Meeting 1',
                         :description => 'blah',
                         :earliest => Time.now + 1.day,
                         :latest => Time.now + 1.week,
                         :decide_by => Time.now + 12.hours,
                         :time_begin => Time.now.midnight,
                         :time_end => Time.now.midnight + 3.hours,
                         :user_id => 1,
                         :length => 2.0 }.merge(options))
  end
end
