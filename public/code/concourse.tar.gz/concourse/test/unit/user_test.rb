require File.dirname(__FILE__) + '/../test_helper'

class UserTest < Test::Unit::TestCase
  # Be sure to include AuthenticatedTestHelper in test/test_helper.rb instead.
  # Then, you can remove it from this and the functional test.
  include AuthenticatedTestHelper
  fixtures :users, :meetings

  def test_should_create_user
    assert_difference User, :count do
      assert create_user.valid?
    end
  end

  def test_should_require_email
    assert_no_difference User, :count do
      u = create_user(:email => nil)
      assert u.errors.on(:email)
    end
  end

  def test_should_require_password
    assert_no_difference User, :count do
      u = create_user(:password => nil)
      assert u.errors.on(:password)
    end
  end

  def test_should_require_password_confirmation
    assert_no_difference User, :count do
      u = create_user(:password_confirmation => nil)
      assert u.errors.on(:password_confirmation)
    end
  end

  def test_should_require_email
    assert_no_difference User, :count do
      u = create_user(:email => nil)
      assert u.errors.on(:email)
    end
  end

  def test_should_reset_password
    users(:quentin).update_attributes(:password => 'password', :password_confirmation => 'password')
    assert_equal users(:quentin), User.authenticate('quentin@example.com', 'password')
  end

  def test_should_not_rehash_password
    users(:quentin).update_attributes(:email => 'quentin2@example.com')
    assert_equal users(:quentin), User.authenticate('quentin2@example.com', 'test')
  end

  def test_should_authenticate_user
    assert_equal users(:quentin), User.authenticate('quentin@example.com', 'test')
  end

  def test_invite_creates_attendance
    users(:fullmoon).invite(meetings(:party_like_mad), false)

    assert !!Attendance.find(:first,
                             :conditions => ['user_id=? and meeting_id=?',
                                              users(:fullmoon).id,
                                              meetings(:party_like_mad).id])
  end

  def test_password_reset_token
    assert_equal users(:fullmoon).salt[4, 6], users(:fullmoon).password_reset_token
  end

  def test_invite_delivers_mail
    ActionMailer::Base.delivery_method = :test
    ActionMailer::Base.perform_deliveries = true
    ActionMailer::Base.deliveries = []

    users(:fullmoon).invite(meetings(:party_like_mad))
    assert_equal 1, ActionMailer::Base.deliveries.size
  end

  protected
    def create_user(options = {})
      User.create({ :email => 'quire@example.com', :password => 'quire', :password_confirmation => 'quire' }.merge(options))
    end
end
