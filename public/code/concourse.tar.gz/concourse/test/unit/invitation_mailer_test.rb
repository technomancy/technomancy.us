require File.dirname(__FILE__) + '/../test_helper'
require 'invitation_mailer'

class InvitationMailerTest < Test::Unit::TestCase
  FIXTURES_PATH = File.dirname(__FILE__) + '/../fixtures'
  CHARSET = "utf-8"
  
  fixtures :meetings, :users, :attendances

  include ActionMailer::Quoting

  def setup
    ActionMailer::Base.delivery_method = :test
    ActionMailer::Base.perform_deliveries = true
    ActionMailer::Base.deliveries = []

    @expected = TMail::Mail.new
    @expected.set_content_type "text", "plain", { "charset" => CHARSET }
  end

  def test_delivery_for_existing_user
    meeting = meetings(:party_like_mad)
    user =   users(:arthur)

    InvitationMailer.deliver_invitation_for_existing_user(user, meeting)    
    delivery = ActionMailer::Base.deliveries.last

    assert delivery

    assert_equal user.email, delivery.to.to_s
  end

  private
    def read_fixture(action)
      IO.readlines("#{FIXTURES_PATH}/invitation_mailer/#{action}")
    end

    def encode(subject)
      quoted_printable(subject, CHARSET)
    end
end
