# == Schema Information
# Schema version: 3
#
# Table name: attendances
#
#  id         :integer       not null, primary key
#  user_id    :integer       
#  meeting_id :integer       
#  times      :text          
#  final      :boolean       
#  created_at :datetime      
#  updated_at :datetime      
#

class Attendance < ActiveRecord::Base
  belongs_to :user
  belongs_to :meeting

  validates_uniqueness_of :user_id, :scope => :meeting_id
  validates_presence_of :user_id, :meeting_id

  # this is a hash (by date) of Arrays of Fixnum ranges
  # each array is a day, and each range specifies a time that works
  serialize :times, Hash

  def times
    self[:times] ||= {}
  end

  def entered?
#    updated_at and created_at and updated_at > created_at
    !! times and not times.empty?
  end

  def good_time?(time, hour = nil)
    time = Time.parse("#{time} #{hour}:00:00") unless time.is_a? Time

    times[time.to_date] &&
      times[time.to_date].include?(time.hour)
  end
  
  def to_s
    "#{user.email} attending #{meeting.name}"
  end
end
