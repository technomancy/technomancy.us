class AccountMailer < ActionMailer::Base

  def password_reset_token(user)
    @subject    = 'Concourse Password Reset'
    @body       = {:user => user}
    @recipients = user.email
    @from       = "Concourse Password Reset <no-reply@localhost>"
  end
end
