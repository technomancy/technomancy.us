class DecisionMailer < ActionMailer::Base
  def meeting_ready_notification(meeting)
    from "Concourse Notification <noreply@concour.se>"
    recipients meeting.organizer.email
    subject "You can now decide on a time for #{meeting.name}."

    body["meeting"] = meeting
  end

  def meeting_decided_notification(meeting)
    from "Concourse Notification <noreply@concour.se>"
    recipients meeting.users.map{ |u| u.email }
    subject "Meeting time for #{meeting.name} has been decided."

    body["meeting"] = meeting
  end
end
