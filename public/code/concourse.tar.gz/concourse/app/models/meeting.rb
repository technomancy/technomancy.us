# == Schema Information
# Schema version: 3
#
# Table name: meetings
#
#  id          :integer       not null, primary key
#  name        :string(255)   
#  description :text          
#  length      :float         
#  user_id     :integer       
#  chosen_time :datetime      
#  earliest    :date          
#  latest      :date          
#  decide_by   :date          
#  created_at  :datetime      
#  updated_at  :datetime      
#  time_begin  :integer       
#  time_end    :integer       
#

class Meeting < ActiveRecord::Base

  belongs_to :organizer, :class_name => 'User'
  has_many :users, :through => :attendances
  has_many :attendances, :dependent => :destroy

  attr_protected :chosen_time

  attr_accessor :attendees
  after_save :add_attendees
  
  validates_presence_of :name, :user_id
  
  def validate
    errors.add(:decide_by, "can't be later than the earliest day.") if decide_by > earliest
    errors.add(:earliest, "must be before the latest day.") if earliest > latest
    errors.add(:chosen_time, "must be between the earliest and latest days.") if chosen_time and not valid_datetime?(chosen_time)
    errors.add(:time_begin, "must be before the latest time.") if time_begin > time_end
  end

  def description
    begin
      RedCloth.new(self[:description]).to_html
    rescue
      self[:description]
    end
  end

  def notify_organizer
    DecisionMailer.deliver_meeting_ready_notification(self)
  end
  
  def decide(t)
    raise "Time out of range." unless valid_datetime?(t)
    update_attribute :chosen_time, t
    users.each do |user|
      user.notify_decision self
    end
  end

  def all_datetimes
    times = {}
    date_range.each { |d| times[d] = hours_that_fit(time_range) }
    times
  end
  
  def times_that_work
    dates = {}
    attendances.each do |a|
      next unless a.times
      a.times.each do |date, hours|
        hours.each do |hour|
          dates[date] ||= {}
          dates[date][hour] ||= []
          dates[date][hour] << a.user_id
        end
      end
    end

    return dates
  end

  def times_that_work_for_all
    dates = {}
    times_that_work.each do |date, hours|
      hours.each do |hour, user_ids|
        dates[date] ||= []
        dates[date] << hour if user_ids.size == attendances.size
      end
      dates[date].sort!
    end

    return dates
  end

  def times_that_work_and_fit
    dates = {}
    times_that_work_for_all.each do |date, hours|
      dates[date] = hours_that_fit(hours)
    end

    return dates
  end

  def hours_that_fit(hours)
    working = []

    hours.sort.each_with_index do |hour, i|
      next if hour < time_begin
      if (hour .. (hour + length - 1)).to_a.map{ |h| hours.include? h }.all?
        working << (hour .. (hour + length - 1).to_i)
      end
    end

    return working
  end

  def no_times_work_and_fit
    times_that_work_and_fit.map{ |hours| hours.last.empty? }.all?
  end
  
  def valid_datetime?(t)
    valid_date?(t.to_date) and valid_time?(t.hour)
  end
  
  def valid_date?(t)
    date_range === t
  end

  def date_range
    (earliest .. latest)
  end

  def date_range_a
    date_range.to_a.map(&:to_s)
  end

  def valid_time?(t)
    time_range === t
  end

  def time_range
    (time_begin .. time_end)
  end

  def time_range_a
    [time_begin, time_end]
  end

  def weeks
    date_range.to_a.inject([[]]) do |wks, day|
      wks << [] if day.wday == 0
      wks.last << day
      wks
    end
  end

  def overdue?
    Date.today > decide_by
  end

  def ready?
    (not attendances.map(&:entered?).include?(false)) and
      (not attendances.empty?)
  end

  def who_at_for_length(date, hour)
    attendances.map do |a|
      if a.times[date]
        a.user if (0 ... length).map{ |i| a.times[date].include?(hour + i) }.all?
      end
    end.compact
  end

  def who_at(date, hour)
    attendances.map{ |a| a.user if a.times[date] and a.times[date].include?(hour) }.compact
  end
  
  def how_many_at(date, hour)
    who_at(date, hour).size
  end
  
  def good_for_everyone(time)
    attendances.map do |attendance|
      attendance.good_time?(time)
    end.all?
  end
  
  def entered_attendances
    attendances.select{ |a| a.entered? }
  end
  
  def status
    chosen_time && :decided or overdue? && :overdue or ready? && :ready or :open
  end

  def add_attendees
    return unless @attendees
     addresses = @attendees.split(' ').map{ |a| a.chomp(',')}

    # check ALL the addresses before sending invitations!
    addresses.each do |address|
      unless address =~ /^([^@\s]+)@((?:[-a-z0-9]+\.)+[a-z]{2,})$/
        errors.add(:attendees, "must be valid email addresses.")
        return
      end
    end

    addresses.each do |address|
      if ! u = User.find_by_email(address)
        random_pass = User.random_password
        u = User.create(:email => address,
                        :password => random_pass,
                        :password_confirmation => random_pass)
        u.invite self, :new
      else
        u.invite self
      end
   end

    # organizer is implied, but don't add it if it was explicit
    Attendance.create(:user_id => organizer.id, :meeting => self) unless @attendees.include?(organizer.email)
  end
end
