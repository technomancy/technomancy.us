class InvitationMailer < ActionMailer::Base
  def invitation_for_existing_user(user, meeting)
    from        "Concourse Invitation <noreply@concour.se>"
    recipients  user.email
    subject     "Your invitation to #{meeting.name}"

    body["url"] =     "http://concour.se/account/login"
    body["user"] =    user
    body["meeting"] = meeting
  end
  
  def invitation_for_new_user(user, meeting)
    from        "Concourse Invitation <noreply@concour.se>"
    recipients  user.email
    subject     "Your invitation to #{meeting.name}"

    body["url"] =     "http://concour.se/account/login"
    body["user"] =    user
    body["meeting"] = meeting
  end
end
