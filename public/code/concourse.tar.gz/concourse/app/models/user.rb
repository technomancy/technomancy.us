# == Schema Information
# Schema version: 3
#
# Table name: users
#
#  id               :integer       not null, primary key
#  email            :string(255)   
#  crypted_password :string(40)    
#  salt             :string(40)    
#  timezone         :string(255)   
#  created_at       :datetime      
#  updated_at       :datetime      
#

require 'digest/sha1'
class User < ActiveRecord::Base

  has_many :organized_meetings, :class_name => 'Meeting'
  has_many :meetings, :through => :attendances
  has_many :attendances


  def invite(meeting, new = false)
    Attendance.create(:user => self, :meeting => meeting)
    if new
      InvitationMailer.deliver_invitation_for_new_user(self, meeting)
    else
      InvitationMailer.deliver_invitation_for_existing_user(self, meeting)
    end
  end

  def notify_decision(meeting)
    DecisionMailer.deliver_meeting_decided_notification(meeting)
  end
  
  def non_initiated_attendances
    meetings - organized_meetings
  end
  
  ##################################################
  # Authentication bits below
  #

  
  # Virtual attribute for the unencrypted password
  attr_accessor :password

  validates_presence_of     :email
  validates_format_of       :email,       :with    => /^([^@\s]+)@((?:[-a-z0-9]+\.)+[a-z]{2,})$/,
                                          :message => 'must be a reasonable address'
  validates_presence_of     :password,                   :if => :password_required?
  validates_presence_of     :password_confirmation,      :if => :password_required?
  validates_length_of       :password, :within => 4..40, :if => :password_required?
  validates_confirmation_of :password,                   :if => :password_required?
  validates_length_of       :email,    :within => 3..100
  validates_uniqueness_of   :email, :case_sensitive => false
  before_save :encrypt_password

  # Authenticates a user by their email and unencrypted password.  Returns the user or nil.
  def self.authenticate(email, password)
    u = find_by_email(email) # need to get the salt
    u && u.authenticated?(password) ? u : nil
  end

  # Encrypts some data with the salt.
  def self.encrypt(password, salt)
    Digest::SHA1.hexdigest("--#{salt}--#{password}--")
  end

  def self.random_password
    Digest::SHA1.hexdigest(Time.now.to_s)[0 .. 8]
  end
  
  # Encrypts the password with the user salt
  def encrypt(password)
    self.class.encrypt(password, salt)
  end

  def authenticated?(password)
    crypted_password == encrypt(password)
  end

  # The token that the user is required to enter upon password reset.
  # Consists of a substring of the salt, thus becoming invalid when a new password is set.
  def password_reset_token
    salt[4, 6]
  end

  protected
  # before filter 
  def encrypt_password
    return if password.blank?
    self.salt = Digest::SHA1.hexdigest("--#{Time.now.to_s}--#{email}--") if new_record?
    self.crypted_password = encrypt(password)
  end
    
  def password_required?
    crypted_password.blank? || !password.blank?
  end
end
