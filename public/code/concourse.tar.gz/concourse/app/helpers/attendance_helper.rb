module AttendanceHelper
  def other_attendees(attendance, date, hour)
    (attendance.meeting.who_at(date, hour).map(&:email) - [attendance.user.email]).join(', ')
  end
end
