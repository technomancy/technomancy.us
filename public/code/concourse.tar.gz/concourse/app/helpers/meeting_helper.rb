module MeetingHelper
  def meeting_lengths
    (1 .. 10)
  end

  def hours
    (5 .. 23).map{ |n| [format_hour(n), n] }
  end

  def textile_message
    begin
      RedCloth
      "<p>#{link_to('Textile', 'http://www.hobix.com/textile')} is available for formatting.</p>"
    rescue
    end
  end

  def attendance_count_icons(meeting)
    meeting.attendances.map do |attendance|
      "<img src='images/#{attendance.entered? ? 'entered' : 'waiting'}.png' alt='#{attendance.user.email}'
 title='#{attendance.user.email}' />"
    end.join ' '
  end
end
