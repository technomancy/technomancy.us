# Methods added to this helper will be available to all templates in the application.
module ApplicationHelper
  def render_navigation_links
    navlinks = [
      ['Home', {:controller => '/'}],
      ['Concourses', {:controller => 'meeting'}],
      ['FAQ', {:controller => 'faq'}],
    ]
    
    str = "<ul>"
    navlinks.each do |link|
      str << "<li"
      str << ' class="selected"' if controller.params[:controller] == link[1][:controller]
      str << ">"
      str << link_to(link[0], link[1])
      str << "</li>"
    end
    str << "</ul>"
    controller.inspect
  end

  def format_hour(h)
    if h > 12
      h -= 12
      "#{h}:00 PM"
    else
      "#{h}:00 AM"
    end
  end

  def filler(week, tag = "td")
    "<#{tag}></#{tag}> " * (7 - week.size) unless (week.first and week.first.wday == 0)
  end

  def attendance_weight(meeting, date, hour)
    ratio = (meeting.how_many_at(date, hour) / meeting.attendances.size.to_f) * 0x22
    "style='background-color: ##{"%x" % (0xcc + ratio)}#{"%x" % (0xdd + ratio)}ff'"
  end
end
