class MeetingController < ApplicationController
  before_filter :login_required
  before_filter :organizer?, :only => [:edit, :update, :decide]

  # for quickly showing it to others, uncomment this and comment before_filter :login_required
#  def current_user
#    @current_user = User.find(1)
#  end
  
  def index
  end

  def new
    @meeting = Meeting.new
    @meeting[:earliest] = Date.today + 2
    @meeting[:latest] = Date.today + 9
    @meeting[:decide_by] = Date.today + 1
    @meeting[:time_begin] = 9
    @meeting[:time_end] = 17
  end

  def create
    @meeting = Meeting.new(params[:meeting])
    @meeting.organizer = current_user
    if @meeting.save
      flash[:notice] = "OK, people have been notified; you will get an email when everyone has entered their times."
      redirect_to :controller => 'attendance', :action => 'show', :id => Attendance.find_by_user_id_and_meeting_id(current_user.id, @meeting.id)
    else
      render :action => 'new'
    end
  end

  def edit
  end
  
  def update
    if @meeting.update_attributes(params[:meeting])
      flash[:notice] = "Meeting saved."
      redirect_to :action => 'index'
    else
      render :action => 'new'
    end
  end

  def decide
    flash.now[:notice] = "Not all the attendees have specified times yet." if @meeting.status == :open

    if request.post?
      chosen_time = Time.parse(params[:chosen_time])
      begin
        @meeting.decide(chosen_time)
        flash[:notice] = "OK, the meeting has been scheduled to start at #{chosen_time.strftime(TIME_STRING)}, and the attendees have been notified."
        redirect_to :action => 'index'
      rescue RuntimeError
        flash[:error] = "That's not a valid time."
      end
    end
  end

  protected

  def organizer?
    @meeting = Meeting.find(params[:id])
    
    if @meeting.organizer == current_user
      return true
    else
      flash[:error] = "This isn't your meeting; quit trying to use it."
      redirect_to :action => 'index'
    end
  end
end
