class AttendanceController < ApplicationController
  before_filter :login_required
  before_filter :attending?

  def show
    session[:no_fancy] = 't' if params[:no_fancy]
    session[:no_fancy] = nil if params[:fancy]
  end
  
  def update
    ready_before = @meeting.ready?

    if params[:times]
      params[:times].each_pair do |date, hours|
        hours.keys.each{ |h| bad_time("time #{h}") unless @meeting.valid_time? h.to_i }
        bad_time("date") unless @meeting.valid_date? Date.parse(date)
        @attendance.times[Date.parse(date)] = hours.keys.map &:to_i
      end
    else
      @attendance.times = {}
    end

    if flash[:error]
      redirect_to :action => 'show', :id => params[:id]
    else
      @attendance.save
      flash[:notice] = "Your times have been saved."
      redirect_to :controller => 'meeting', :action => 'index'
    end

    @meeting.reload
    @meeting.notify_organizer if @meeting.ready? and !ready_before
  end

  protected
  
  def attending?
    @attendance = Attendance.find(params[:id])

    if @attendance and @meeting = @attendance.meeting and @attendance.user == current_user
      return true
    else
      flash[:error] = "You aren't allowed to do that."
      redirect_to :controller => 'meeting'
    end
  end

  def bad_time(dt)
    flash[:error] = "You specified a #{dt} outside of the meeting's allowed range."
  end
end
