class AccountController < ApplicationController
  before_filter :login_required, :except => [ :login, :signup, :forgot_password, :enter_password_token, :faq ]
  
  def login
    redirect_to home_url if current_user
    return unless request.post?
    
    if self.current_user = User.authenticate(params[:email], params[:password])
      redirect_to session[:return_to] || home_url
      flash[:notice] = "Logged in successfully"
    else
      flash[:error] = "Wrong username or password"
    end
  end

  def signup
    @user = User.new(params[:user])
    return unless request.post?
    if @user.save
      self.current_user = @user
      redirect_to :controller => 'meeting', :action => 'index'
      flash[:notice] = "Thanks for signing up! You're all logged in now."
    else
      flash[:error] = "Sorry; there was a problem creating your account."
    end
  end
  
  def logout
    self.current_user = nil
    flash[:notice] = "You have been logged out."
    redirect_back_or_default(:controller => 'account', :action => 'login')
  end
  
  def forgot_password
    return unless request.post?

    if(@user = User.find_by_email(params[:email]))
      AccountMailer.deliver_password_reset_token(@user)
      redirect_to :action => "enter_password_token", :email => @user.email
    else
      flash[:error] = "No user found with the given email address"
    end
  end

  def enter_password_token
    @user = User.find_by_email(params[:email])
    return unless request.post?

    return flash[:error] = "Token incorrect." unless @user && @user.password_reset_token == params[:token]
  
    # Todo: User does not revalidates empty passwords, when the user already have one. Is this OK?
    return flash[:error] = "No new password set." if params[:user][:password].blank?

    if @user.update_attributes(params[:user])
      flash[:notice] = "New password saved."
      redirect_to :action => 'login'
    end
  end
end
