var selectedColor = '#DDEEFF';
var deselectedColor = '#BBCCEE';
var dragging;
var dragStartPos;
var dragStartElement;
var dragEndElement;
var dragStartState;

function clickWeek(event){
  if(!event) { event = window.event; } // for IE compatibility
  if(isCell(Event.element(event))){
    dragging = true;
    dragStartPos = adjustedCoords(event);
    dragStartElement = Event.element(event);
    dragStartState = cellInput(dragStartElement).checked;
    drawRegion(dragStartPos, dragStartPos, event);
  }
  else {releaseWeek();}
}

function moveWeek(event){
  if(!event) { event = window.event; } // for IE compatibility
  if(dragging) {
    drawRegion(dragStartPos, adjustedCoords(event), event);
  }
  return false;
}

function releaseWeek(){
  if(dragging){
    dragging = false;
    Element.hide($('select-rect'));
    selectRegion(dragStartElement, dragEndElement);
  }
}

function drawRegion(start, end, event){
  if(outOfBounds(event)){ return; }
  dragEndElement = Event.element(event);
  Element.show($('select-rect'));

  $('select-rect').style.top = Math.min(start[1], end[1]) + "px";
  $('select-rect').style.height = Math.abs(start[1] - end[1]) + "px";
  $('select-rect').style.left = Math.min(start[0], end[0]) + "px";
  $('select-rect').style.width = Math.abs(start[0] - end[0]) + "px";
}

function selectRegion(start, end){
  $R(Math.min(cellHour(start), cellHour(end)), Math.max(cellHour(start), cellHour(end))).each(function(hour) {
      $R(Math.min(cellDay(start), cellDay(end)), Math.max(cellDay(start), cellDay(end))).each(function(day) {
	  selectCell($('w' + cellWeek(start) + 'd' + day + 'h' + hour));
	})
	})
}

function selectCell(cell){
  new Effect.Highlight(cell);
  if(dragStartState){
    // Browser bug: changing class does not always change color!
    cell.style.backgroundColor = deselectedColor;
    if(cellInput(cell).checked && cellCount(cell).innerHTML > '0') {cellCount(cell).innerHTML = parseInt(cellCount(cell).innerHTML) - 1;}
    }
  else{
    cell.style.backgroundColor = selectedColor;
    if(!cellInput(cell).checked) {cellCount(cell).innerHTML = parseInt(cellCount(cell).innerHTML) + 1;}
  }
  cellInput(cell).checked = !dragStartState;
}


function adjustedCoords(event){ // get absolute coords rather than relative to scrolling
  return [Event.pointerX(event), Event.pointerY(event)];
}

function outOfBounds(event) {
  if (!isCell(Event.element(event)) || !isCell(dragStartElement)) {return true;}
  if (cellWeek(dragStartElement) != cellWeek(Event.element(event))) { return true; }
}

function disableSelection(element) {
    element.onselectstart = function() {
        return false;
    };
    element.unselectable = "on";
    element.style.MozUserSelect = "none";
    element.style.cursor = "default";
}

function madrobbyDisableSelection() {
  if(/MSIE/.test(navigator.userAgent)) {
    document.onselectstart = function(event) {
      if(!/input|textarea/i.test(Event.element(window.event).tagName))
	return false;
    };
  } else { // assume DOM
    document.onmousedown = function(event) {
      if(!/input|textarea/i.test(Event.element(event).tagName))
	return false;
    };
  }
}

function fixColor(elem) {
  // this is necessary because a refresh will reset the colors but keep the checkboxes the same
  elem.style.backgroundColor = elem.childNodes[1].checked ? selectedColor : deselectedColor;
}

function cellCount(cell) {
  return $$("#" + cell.id + " span")[0];
}
