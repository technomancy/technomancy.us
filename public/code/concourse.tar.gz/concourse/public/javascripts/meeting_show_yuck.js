// oh so old school js...
window.onload = function() {
  meeting = new Meeting();

  if (meeting) {
    document.getElementById('meeting_show_form').onsubmit = function() {
      document.getElementById('times').value = meeting.get_times();
      //return false;
    }
  }

}
function Meeting() {
  if (typeof meeting_settings == "undefined") return false;
  this.cols = meeting_settings.days.length;
  this.rows = meeting_settings.hours[1] - meeting_settings.hours[0] + 1;
  this.maxusers = 0;
  this.render_table();
  this.init_days();
  this.process_attendances();
  this.plot_attendances();
}
Meeting.prototype.toString = function() {
  return this.days.toString();
}
Meeting.prototype.init_days = function() {
  var col, row, tmpday;

  this.days = [];
  for (col=0; col<this.cols; col++) {
    tmpday = [];
    for (row=0; row<this.rows; row++) {
      //tmpday.push({users: 0, selected: false, toString: function(){return this.users + ': ' + this.selected + '\n'}});
      tmpday.push({users: 0, selected: false});
    }
    this.days.push(tmpday);
  }
}

// omg, don't tell anyone i wrote this!
Meeting.prototype.process_attendances = function() {
  var user, day, ranges, range, i;
  for (user in current_attendances) {
    for (day in current_attendances[user]) {
      dayindex = meeting_settings.days.indexOf(day);
      ranges = current_attendances[user][day];
      for (rangei=0; rangei<ranges.length; rangei++) {

        range = ranges[rangei];
        // got a range. like this [7, 12]
        for (i=range[0]; i<=range[1]; i++) {
          ri = i-meeting_settings.hours[0];
          if (my_user_id == user) {
            this.days[dayindex][ri].selected = true;
          } else {
            this.days[dayindex][ri].users++;
            if (this.days[dayindex][ri].users > this.maxusers) {
              this.maxusers = this.days[dayindex][ri].users;
            }
          }
        }

      }
    }
  }
}

Meeting.prototype.plot_attendances = function() {
  var day, hour, row, cell, rows, cells, cn;
  rows = this.table.rows
  for (row=1; row<rows.length; row++) {
    cells = rows[row].cells;
    for (cell=1; cell<cells.length; cell++) {
      cn = "shade" + Math.ceil(5 * this.days[cell-1][row-1].users / this.maxusers);
      if (this.days[cell-1][row-1].selected) {
        cn += " selected";
      }
      cells[cell].title = this.days[cell-1][row-1].users + ' peep' + (this.days[cell-1][row-1].users == 1 ? '' : 's');
      YAHOO.util.Dom.addClass(cells[cell], cn);
    }
  }
}

Meeting.prototype.render_table = function() {
  var s = '', row, col;
  s += '<tr><th>&nbsp;</th>'
  for (col=0; col<this.cols; col++) {
    s += '<th>' + meeting_settings.days[col] + '</th>';
  }
  s += '</tr>';
  for (row=0; row<this.rows; row++) {
    s += '<tr><th>' + (meeting_settings.hours[0] + row) + '</th>'
    for (col=0; col<this.cols; col++) {
      //s += '<td id="' + row + '-' + col + '">' + row + '-' + col + '</td>';
      s += '<td id="' + row + '-' + col + '">&nbsp;</td>';
    }
    s += '</tr>';
  }
  s = '<table onclick="clicky(event, this)">' + s + '</table>';
  x = document.getElementById("table_container");
  y = document.createElement('DIV');
  y.id = "week-container";
  y.innerHTML = s;
  x.appendChild(y);
  this.table = document.getElementsByTagName('TABLE')[0];
}
Meeting.prototype.toggle_cell = function(td) {
  var splitid = td.id.split('-');
  var cell = this.days[splitid[1]][splitid[0]];
  if (cell.selected) {
    YAHOO.util.Dom.removeClass(td, "selected");
  } else {
    YAHOO.util.Dom.addClass(td, "selected");
  }
  cell.selected = !cell.selected;
}
Meeting.prototype.get_times = function() {
  var day, hours, hour, res = {}, x, s = '';

  for (day=0; day<this.days.length; day++) {
    hours = this.days[day];
    for (hour=0; hour<hours.length; hour++) {
      if (hours[hour].selected) {
        if (typeof res[meeting_settings.days[day]] == 'undefined') {
          res[meeting_settings.days[day]] = [];
        }
        res[meeting_settings.days[day]].push(hour+meeting_settings.hours[0])
      }
    }
  }
  for (x in res) {
    s += "'" + x + "': " + "[" + res[x] + "],\n";
  }
  s = '{' + s.substring(0, s.length-2) + '}';
  return s;
}

function clicky(e, o) {
  var s = '';
  for (var x in e) {
    s += x + ': ' + e[x] + '\n';
  }
  if (e.target && e.target.tagName && e.target.tagName == 'TD' && e.target.id) {
    meeting.toggle_cell(e.target);
    return;
  }
  if (e.srcElement && e.srcElement.tagName && e.srcElement.tagName == 'TD' && e.srcElement.id) {
    meeting.toggle_cell(e.srcElement);
  }
}

