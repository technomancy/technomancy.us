function chooseTime(event, length, timestring) {
  if(!event) { event = window.event; } // for IE compatibility
  target = Event.element(event);
  cellInput(target).checked = true;

  for(i=0; i < length; i++) {
    new Effect.Highlight($('w' + cellWeek(target) + 'd' + cellDay(target) + 'h' + (cellHour(target) + i)));
  }

  $('decide').value = "Decide on " + timestring;
}
