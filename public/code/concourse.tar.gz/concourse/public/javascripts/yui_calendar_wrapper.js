YAHOO.namespace("concourse.calendar");

yui_calendar_counter = 0;

function add_yui_calendar(input) {
  yui_calendar_counter++;
  var cal = 'cal' + yui_calendar_counter;
  var cal_reference_str = 'YAHOO.concourse.calendar.' + cal;

  var val = input.value.replace('-', '/');
  var default_date = new Date();
  default_date.setFullYear(input.value.match(/^\d+/), input.value.replace(/^\d+-/, '').replace(/-\d+/, ''), input.value.match(/\d+$/))
  var tomorrow = YAHOO.widget.DateMath.add(new Date(), YAHOO.widget.DateMath.DAY, 1);
  if (default_date < tomorrow) {
    default_date = tomorrow;
  }

  YAHOO.concourse.calendar[cal] = new YAHOO.widget.Calendar(cal_reference_str, input.id + "_cal", default_date.to_yui_monthyear(), default_date.to_yui_date());
  YAHOO.concourse.calendar[cal].minDate = tomorrow;
  YAHOO.concourse.calendar[cal].onSelect = function() {
    input.value = this.getSelectedDates()[0].to_YMD();
  }
  YAHOO.concourse.calendar[cal].render();
}

