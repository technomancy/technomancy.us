Date.prototype.getRealMonth = function() {
  return this.getMonth() + 1;
}
Date.prototype.to_yui_monthyear = function() {
  return this.getMonth() + '/' + this.getFullYear();
}
Date.prototype.to_yui_date = function() {
  return this.getMonth() + '/' + this.getDate() + '/' + this.getFullYear();
}
Date.prototype.to_YMD = function() {
  return  this.getFullYear() + '-' + this.getRealMonth() + '-' + this.getDate();
}

Array.prototype.indexOf = function(item) {
  for (var i=0; i<this.length; i++) {
    if (this[i] == item) {
      return i;
    }
  }
  return -1;
}

function toggleWeekInputs() {
  $$('#week-container input').each(function(c){Element.toggle(c)});
}

function isCell(elem) {
  if(!elem) { return false; }
  return !! elem.id.match(/w\d+d\d+h\d+/);
}

function cellWeek(cell) {
  return parseInt(cell.id.match(/w(\d*)/)[1]);
}

function cellDay(cell) {
  return parseInt(cell.id.match(/d(\d*)/)[1]);
}

function cellHour(cell) {
  return parseInt(cell.id.match(/h(\d*)/)[1]);
}

function cellInput(cell) {
  return $$("#" + cell.id + " input")[0];
}
