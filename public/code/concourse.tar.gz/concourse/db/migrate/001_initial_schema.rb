class InitialSchema < ActiveRecord::Migration
  def self.up
    create_table "users", :force => true do |t|
      t.column :email,            :string
      t.column :crypted_password, :string, :limit => 40
      t.column :salt,             :string, :limit => 40
      t.column :timezone,         :string

      t.column :created_at,       :datetime
      t.column :updated_at,       :datetime
    end

    create_table "meetings", :force => true do |t|
      t.column :name, :string
      t.column :description, :text
      t.column :length, :float

      t.column :user_id, :integer
      t.column :chosen_time, :datetime

      t.column :earliest, :datetime
      t.column :latest, :datetime
      t.column :decide_by, :datetime

      t.column :created_at,       :datetime
      t.column :updated_at,       :datetime
    end
    
    create_table "attendances", :force => true do |t|
      t.column :user_id, :integer
      t.column :meeting_id, :integer
      t.column :times, :text
      t.column :final, :boolean
        
      t.column :created_at,       :datetime
      t.column :updated_at,       :datetime
    end
  end

  def self.down
    # oh noes! everything will be gone...
    drop_table "users"
    drop_table "meetings"
    drop_table "attendances"
  end
end
