class MeetingTimeRanges < ActiveRecord::Migration
  def self.up
    add_column :meetings, :time_begin, :integer
    add_column :meetings, :time_end, :integer
    
    change_column :meetings, :decide_by, :date
    change_column :meetings, :earliest, :date
    change_column :meetings, :latest, :date
  end

  def self.down
    remove_column :meetings, :time_begin
    remove_column :meetings, :time_end

    change_column :meetings, :decide_by, :datetime
    change_column :meetings, :earliest, :datetime
    change_column :meetings, :latest, :datetime
  end
end
