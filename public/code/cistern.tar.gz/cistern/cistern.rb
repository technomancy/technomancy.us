require 'sdl'

require 'system'
require 'floor'
require 'player'

# initialization
SDL.init( SDL::INIT_VIDEO )
screen = SDL::setVideoMode(WIDTH,HEIGHT,16,SDL::SWSURFACE)
SDL::WM.setCaption 'Cistern', 'Cistern for Ruby'
SDL::TTF.init
font=SDL::TTF.open('font.ttf',20)
font.style=SDL::TTF::STYLE_NORMAL

White=screen.format.mapRGB(0xff,0xff,0xff)
Red=screen.format.mapRGB(0xff,0,0)
White_Array= [0xff,0xff,0xff]


event=SDL::Event.new

floors = []
(HEIGHT / LEVEL_HEIGHT).times { |i| floors << Floor.new(i * LEVEL_HEIGHT) }

player = Player.new

$y = 0

# main loop

while true

  if event.poll != 0
    break if event.type==SDL::Event::QUIT
    break if event.type==SDL::Event::KEYDOWN and event.keySym==SDL::Key::ESCAPE
  end

  SDL::Key::scan

  player.move :left if SDL::Key::press?(SDL::Key::LEFT)
  player.move :right if SDL::Key::press?(SDL::Key::RIGHT)

  # recycle floors
  if $y % LEVEL_HEIGHT == 0
    floors.shift
    floors.push Floor.new($y + HEIGHT)
  end

  player.supported = floors.collect do |f|
    if f.collision? player.x, player.y, PLAYER_WIDTH, PLAYER_HEIGHT
      f.highlight
      true
    end
  end

  (player.supported.include? true) ? player.stop : player.fall
  
  now=SDL::getTicks
  sleep $wait
  
  screen.fillRect(0,0,640,480,0)
  screen.drawRect(LEFT_WALL,CEILING,RIGHT_WALL,FLOOR,White)
  
  player.draw(screen)
  floors.each{|i| i.draw(screen) }

  font.drawSolidUTF8(screen,"level:#{player.level}",150,10,*White_Array)
  font.drawSolidUTF8(screen,"life:#{player.life}",50,10,*White_Array)

  ObjectSpace.garbage_collect
  screen.flip

  $y += DROP_SPEED # inexorably falling

end
