WIDTH = 640
HEIGHT = 480

LEFT_WALL = 10
RIGHT_WALL = WIDTH - LEFT_WALL * 2
CEILING = 10
FLOOR = HEIGHT - CEILING * 2

GRAVITY = 1
LEVEL_HEIGHT = 60 # each floor in pixels
DROP_SPEED = 5

PLAYER_WIDTH = 10
PLAYER_HEIGHT = 40

MOVE_SPEED = 5

$wait = 0.01 # seconds

def setup_bmp(filename)
  graph=SDL::Surface.loadBMP(filename)
  graph.setColorKey SDL::SRCCOLORKEY, graph[0,0]
  graph=graph.displayFormat
end

