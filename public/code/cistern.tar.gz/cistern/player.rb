class Player

  attr_reader :life, :x, :y
  attr_accessor :supported

  LEFT_KEYS = [';', 'a']
  RIGHT_KEYS = ['q', 'o']

  def initialize
    @x = WIDTH / 2
    @y = 0
    @yy = @xx = 0
    @life = 10
    @sprite = setup_bmp 'player.bmp'
  end

  def move(direction)
    @x -= MOVE_SPEED if direction == :left and @x > 0
    @x += MOVE_SPEED if direction == :right and @x < WIDTH - PLAYER_WIDTH
  end

  def fall
    @y += @yy
    @yy += GRAVITY

    die if @y - $y > HEIGHT
  end

  def stop
    @yy = 0
    @y -= (@y % LEVEL_HEIGHT) - LEVEL_HEIGHT / 2
  end

  def level
    $y / LEVEL_HEIGHT
  end

  def draw(screen)
    screen.put(@sprite, @x, @y - $y)
  end

end


