FLOOR_WIDTH = 100
FLOOR_HEIGHT = 10

class Floor

  attr_reader :x, :y, :type

  def initialize(y)
    @x = (rand * (WIDTH - FLOOR_WIDTH)).to_i
    @y = y
#    @type = case rand * 10
#            when 1; :spike
#            when 2; :disappear
#            when 3; :bounce
#            else; :normal
#            end
    @color = White
  end

  def draw(screen)
    screen.drawRect(@x, @y - $y, FLOOR_WIDTH, FLOOR_HEIGHT, @color)
  end

  def collision?(x, y, width, height)
    true if x + width > @x and x < @x + FLOOR_WIDTH and
      y + height > @y and y < @y + FLOOR_HEIGHT
  end

  def highlight
    @color = Red
  end

end


